import {useEffect, useRef, useState} from 'react';
import {arena, forensicsQuiz, labQuiz, type Q} from '../content';

function Defense({onWin}: {onWin: (score: number) => void}) {
  const [run, setRun] = useState(false);
  const [temp, setTemp] = useState(40);
  const [secs, setSecs] = useState(0);
  const [valve, setValve] = useState(0);
  const [pwr, setPwr] = useState(100);
  const [res, setRes] = useState<'win' | 'lose' | null>(null);
  const c = useRef({valve: 0, pwr: 100});

  useEffect(() => {
    if (!run) return;
    const id = setInterval(() => {
      setSecs((s) => s + 0.25);
      setTemp((t) => Math.max(25, t + 0.12 + 0.3 * (c.current.pwr / 100) - 0.55 * (c.current.valve / 180) + t * 0 + 0.004 * 0));
    }, 250);
    return () => clearInterval(id);
  }, [run]);

  useEffect(() => {
    if (!run) return;
    if (temp >= 70) {
      setRun(false);
      setRes('lose');
    } else if (secs >= 30) {
      setRun(false);
      setRes('win');
      onWin(Math.round(70 - temp + pwr));
    }
  }, [temp, secs, run, pwr, onWin]);

  const start = () => {
    setTemp(40); setSecs(0); setRes(null); setRun(true);
  };
  return (
    <div className="card">
      <p className="m-0">Keep the cell below 70 °C (CRITICAL) for 30 s. Cooling costs nothing, but throttling power costs load — find the balance.</p>
      <p className="mt-3 mb-0 font-mono text-3xl" style={{color: temp >= 55 ? '#ef4444' : temp >= 45 ? '#f59e0b' : '#10b981'}}>{temp.toFixed(1)} °C</p>
      <progress className="w-full" max={30} value={secs} aria-label="Seconds survived" />
      {temp > 55 && run && <p className="m-0 text-sm" style={{color: '#c084fc'}}>Domino risk: the neighboring cell is heating.</p>}
      <label className="mt-3 block text-sm">Cooling valve: {valve}°
        <input className="w-full" type="range" min={0} max={180} value={valve} onChange={(e) => { c.current.valve = +e.target.value; setValve(+e.target.value); }} />
      </label>
      <label className="mt-2 block text-sm">Load power: {pwr}%
        <input className="w-full" type="range" min={0} max={100} value={pwr} onChange={(e) => { c.current.pwr = +e.target.value; setPwr(+e.target.value); }} />
      </label>
      <button className="btn mt-4" onClick={start}>{run ? 'Restart' : 'Start simulation'}</button>
      {res === 'win' && <p role="status" className="text-ok">Runaway arrested. Edge Safety badge earned.</p>}
      {res === 'lose' && <p role="status" className="text-crit">CRITICAL reached — the relay cut the load. Open the valve sooner and try again.</p>}
    </div>
  );
}

function Quiz({qs, onDone}: {qs: Q[]; onDone: (score: number) => void}) {
  const [i, setI] = useState(0);
  const [pick, setPick] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  if (i >= qs.length)
    return (
      <div className="card">
        <p className="m-0">Score: {score}/{qs.length}{score >= 3 ? ' — badge earned.' : ' — 3 correct earns the badge.'}</p>
        <button className="btn mt-3" onClick={() => { setI(0); setScore(0); setPick(null); }}>Try again</button>
      </div>
    );
  const q = qs[i];
  const choose = (k: number) => {
    if (pick !== null) return;
    setPick(k);
    if (k === q.a) setScore((s) => s + 1);
  };
  const next = () => {
    if (i + 1 >= qs.length) onDone(score);
    setI(i + 1);
    setPick(null);
  };
  return (
    <div className="card">
      <p className="lbl m-0">Question {i + 1} of {qs.length}</p>
      <p className="mt-2 font-mono">{q.q}</p>
      <div className="grid gap-2">
        {q.o.map((o, k) => (
          <button key={o} className="btn text-left" disabled={pick !== null} onClick={() => choose(k)} style={pick !== null ? {borderColor: k === q.a ? '#10b981' : k === pick ? '#ef4444' : '#1e293b'} : undefined}>{o}</button>
        ))}
      </div>
      {pick !== null && (
        <div role="status">
          <p className="mt-3">{pick === q.a ? 'Correct. ' : 'Not quite. '}{q.why}</p>
          <button className="btn" onClick={next}>{i + 1 >= qs.length ? 'See score' : 'Next question'}</button>
        </div>
      )}
    </div>
  );
}

export function LearningArena() {
  const [tab, setTab] = useState<'defense' | 'lab' | 'forensics'>('defense');
  const [badges, setBadges] = useState<string[]>([]);
  const [scores, setScores] = useState<Record<string, number>>({});
  const earn = (k: string, badge: string, score: number, min: number) => {
    setScores((s) => ({...s, [k]: Math.max(s[k] ?? 0, score)}));
    if (score >= min) setBadges((b) => (b.includes(badge) ? b : [...b, badge]));
  };
  const tabs = [['defense', 'Runaway Defense'], ['lab', 'Sensor & Fault Lab'], ['forensics', 'Black-Box Forensics']] as const;
  return (
    <section id="arena" className="wrap">
      <div data-reveal>
        <p className="lbl">{arena.eyebrow}</p>
        <h2 className="text-display mt-3 max-w-3xl">{arena.heading}</h2>
        <p className="mt-4 max-w-2xl text-dust">{arena.body}</p>
      </div>
      <div role="tablist" aria-label="Arena games" className="mt-8 flex flex-wrap gap-2">
        {tabs.map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} className="btn" style={tab === k ? {background: 'rgba(111,182,255,.2)'} : undefined} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>
      <div className="mt-4 max-w-2xl" role="tabpanel">
        {tab === 'defense' && <Defense onWin={(s) => earn('Defense', 'Runaway Arrested', s, 1)} />}
        {tab === 'lab' && <Quiz key="lab" qs={labQuiz} onDone={(s) => earn('Lab', 'Sensor Whisperer', s, 3)} />}
        {tab === 'forensics' && <Quiz key="for" qs={forensicsQuiz} onDone={(s) => earn('Forensics', 'Black-Box Detective', s, 3)} />}
      </div>
      <p className="mt-6 font-mono text-sm text-dust">
        Best scores: {Object.keys(scores).length ? Object.entries(scores).map(([k, v]) => `${k} ${v}`).join(' · ') : 'none yet'} · Badges: {badges.length ? badges.join(', ') : 'none yet'}
      </p>
    </section>
  );
}
