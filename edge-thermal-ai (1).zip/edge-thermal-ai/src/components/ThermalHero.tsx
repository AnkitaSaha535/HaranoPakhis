import {useEffect, useRef} from 'react';
import {hero} from '../content';
import {useReducedMotion} from '../hooks/useReducedMotion';
import {registerScrollHandler} from '../lib/scroll';

const clamp = (v: number) => Math.min(1, Math.max(0, v));
// Vertical rates (fraction of viewport height) for horizon, title, foreground: desktop (d) and mobile (m) cuts.
const RATE = {d: [0.1, 0.3, 0.6], m: [0.08, 0.2, 0.4]};

export function ThermalHero() {
  const L = useRef<(HTMLDivElement | null)[]>([]);
  const core = useRef<HTMLSpanElement>(null);
  const reduced = useReducedMotion();

  useEffect(() => {
    const set = (i: number, tr: string, op?: number) => {
      const el = L.current[i];
      if (!el) return;
      el.style.transform = tr;
      if (op !== undefined) el.style.opacity = String(op);
    };
    return registerScrollHandler((y, vh) => {
      const p = reduced ? 1 : clamp(y / (vh * 1.5));
      const r = innerWidth < 768 ? RATE.m : RATE.d;
      const haze = clamp(p / 0.3); // the haze clears first...
      const rise = clamp((p - 0.3) / 0.45); // ...then the hotspot core climbs
      set(1, `translate3d(0,${-p * vh * r[0]}px,0)`);
      set(2, `translate3d(0,${(1 - rise) * 0.4 * vh}px,0) scale(${0.6 + 0.4 * rise})`, rise);
      set(3, `translate3d(0,${-p * vh * r[1]}px,0)`);
      set(4, `translate3d(0,${-p * vh * r[2]}px,0)`);
      set(5, 'none', 1 - haze);
      if (core.current) core.current.textContent = (24 + rise * 38).toFixed(1);
    });
  }, [reduced]);

  const ref = (i: number) => (el: HTMLDivElement | null) => {
    L.current[i] = el;
  };
  const layer = 'absolute inset-0 will-change-transform';

  return (
    <section id="hero" aria-label="ActionBeforeReaction hero" className="relative h-[250vh]">
      <div className="sticky top-0 h-screen overflow-hidden">
        <div ref={ref(0)} aria-hidden="true" className={layer} style={{background: 'linear-gradient(#05070c,#0b0f18 70%,#0f172a)'}} />
        <div ref={ref(1)} aria-hidden="true" className={layer} style={{background: 'linear-gradient(180deg,transparent 55%,rgba(239,68,68,.18) 75%,transparent 90%)'}} />
        <div ref={ref(2)} aria-hidden="true" className={`${layer} flex items-end justify-center`}>
          <div className="mb-[18vh] size-[60vmin] rounded-full" style={{background: 'radial-gradient(circle,#fff6d6 0%,#f59e0b 25%,#ef4444 50%,transparent 72%)'}} />
        </div>
        <div ref={ref(3)} className={`${layer} flex flex-col items-center justify-center px-4 text-center`}>
          <h1 className="font-display text-hero pl-[0.24em] text-sunlit">
            {hero.title.map((w) => <span key={w} className="block">{w}</span>)}
          </h1>
          <p className="mt-6 max-w-xl text-lead text-regolith">{hero.kicker}</p>
          <p className="mt-3 font-mono text-xs text-dust">{hero.site}</p>
        </div>
        <div ref={ref(4)} aria-hidden="true" className={`${layer} flex items-end justify-center gap-6 pb-[6vh]`}>
          <div className="grid w-28 grid-cols-2 gap-1.5">
            {['#1e3a5f', '#1e3a5f', '#ef4444', '#c2410c'].map((c, i) => <div key={i} className="aspect-square rounded-md" style={{background: c}} />)}
          </div>
          <div className="grid w-28 grid-cols-8 gap-px">
            {Array.from({length: 64}, (_, i) => {
              const d = Math.hypot((i % 8) - 1, Math.floor(i / 8) - 6);
              return <div key={i} className="aspect-square" style={{background: `hsl(${Math.max(0, 220 - 40 * (7 - d))} 85% 50%)`, opacity: 0.85}} />;
            })}
          </div>
        </div>
        <div ref={ref(5)} aria-hidden="true" className={`${layer} z-30 flex items-end justify-center pb-24`} style={{background: 'radial-gradient(ellipse at 30% 40%,rgba(139,144,155,.5),transparent 60%),radial-gradient(ellipse at 70% 60%,rgba(111,182,255,.25),transparent 55%),rgba(5,7,12,.92)', backdropFilter: 'blur(6px)'}}>
          <span className="lbl">Scroll to clear the haze</span>
        </div>
        <p className="absolute bottom-5 left-5 z-40 font-mono text-xs text-dust md:left-10">&lt;300 µs edge inference</p>
        <p className="absolute bottom-5 right-5 z-40 font-mono text-xs text-dust md:right-10">Inside-Core X-Ray <span ref={core} className="text-warn">24.0</span> °C</p>
      </div>
    </section>
  );
}
