import {useEffect, useRef, useState} from 'react';
import {edge, intro, modules} from '../content';
import {findAnomalies} from '../lib/edge';
import {registerScrollHandler} from '../lib/scroll';
import {DOMINO, grid8, heatColor, recon, stateOf, useTelemetry} from '../lib/telemetry';

function Gauge({label, v, max, unit, color}: {label: string; v: number; max: number; unit: string; color: string}) {
  const f = Math.min(1, Math.max(0, v / max));
  const d = 'M10 70 A50 50 0 0 1 110 70';
  return (
    <figure className="card m-0 text-center" aria-label={`${label}: ${Math.round(v)} ${unit}`}>
      <svg viewBox="0 0 120 80" className="mx-auto w-full max-w-[190px]" aria-hidden="true">
        <path d={d} fill="none" stroke="#1e293b" strokeWidth="10" strokeLinecap="round" />
        <path d={d} fill="none" stroke={color} strokeWidth="10" strokeLinecap="round" pathLength={1} strokeDasharray={`${f} 1`} />
      </svg>
      <p className="m-0 -mt-6 font-mono text-2xl">{Math.round(v)}<span className="text-sm text-dust"> {unit}</span></p>
      <figcaption className="lbl mt-1">{label}</figcaption>
    </figure>
  );
}

function Trend({data, max, color, label}: {data: number[]; max: number; color: string; label: string}) {
  const pts = data.map((v, i) => `${(i / 59) * 300},${78 - Math.min(1, v / max) * 74}`).join(' ');
  return (
    <div className="card">
      <p className="lbl m-0">{label}</p>
      <svg viewBox="0 0 300 80" className="w-full" role="img" aria-label={`${label} trend, last 60 seconds`}>
        <polyline points={pts} fill="none" stroke={color} strokeWidth="2" vectorEffect="non-scaling-stroke" />
      </svg>
    </div>
  );
}

export function LiveDashboard() {
  const {p, hist, log, src, off} = useTelemetry();
  const s = stateOf(p.cl, off);
  const [hv, setHv] = useState<number | null>(null);
  const hm = p.hm && p.hm.length === 64 ? p.hm : grid8(p.t.map((v, i) => (v < 0 ? recon(p.t, i) : v)));
  const an = new Set(p.hm ? findAnomalies(p.hm) : []);
  const bytes = JSON.stringify({...p, hm: undefined}).length;
  const saved = (100 - (bytes / 12800) * 100).toFixed(1);
  const reel = useRef<(HTMLElement | null)[]>([]);

  // Reel: whichever module sits nearest the viewport centre is the one in focus.
  useEffect(
    () =>
      registerScrollHandler((_y, vh) => {
        let best = 0, d = Infinity;
        reel.current.forEach((el, i) => {
          if (!el) return;
          const r = el.getBoundingClientRect();
          const dd = Math.abs(r.top + r.height / 2 - vh / 2);
          if (dd < d) { d = dd; best = i; }
        });
        reel.current.forEach((el, i) => {
          if (el) el.dataset.focus = i === best ? '1' : '0';
        });
      }),
    [],
  );

  const download = () => {
    const rows = log.length ? log : hist;
    const csv = ['id,up,t1,t2,t3,t4,core,gas,sc,cl,pwr,srv,rel,dom,hs', ...rows.map((r) => [r.id, r.up, ...r.t, r.core, r.gas, r.sc, r.cl, r.pwr, r.srv, r.rel, r.dom, r.hs].join(','))].join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], {type: 'text/csv'}));
    a.download = 'blackbox_event_log.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <section id="dashboard" className="wrap">
      <div data-reveal>
        <p className="lbl">{intro.eyebrow}</p>
        <h2 className="text-display mt-3 max-w-3xl">{intro.heading}</h2>
        <p className="mt-4 max-w-2xl text-dust">{intro.body}</p>
      </div>

      <div className="card mt-10 flex flex-wrap items-center justify-between gap-4" style={{borderColor: s.c}} role="status" aria-live="polite">
        <div>
          <p className="lbl m-0">Node {p.id} · {src === 'bridge' ? 'live bridge' : 'simulator'}</p>
          <p className="font-display m-0 text-2xl" style={{color: s.c}}>{s.n}</p>
          {off && <p className="m-0 text-sm text-dust">Edge Autonomous Active — no packet for 5 s</p>}
        </div>
        <p className="m-0 font-mono">Threat Score <b className="text-2xl">{p.sc}</b>/100</p>
        <p className="m-0 font-mono text-sm text-dust">Hash {p.hs} · {p.us} µs · SD rows {p.sd} · queue {p.q} · ETA {p.ttr < 0 ? 'stable' : `${p.ttr}s`}</p>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Gauge label="Inside-Core X-Ray" v={p.core} max={100} unit="°C" color={s.c} />
        <Gauge label="MQ-2 Gas" v={p.gas} max={2500} unit="ppm" color={p.gas >= 1800 ? '#ef4444' : p.gas >= 600 ? '#f59e0b' : '#10b981'} />
        <Gauge label="Cooling Valve" v={p.srv} max={180} unit="°" color="#6fb6ff" />
        <Gauge label="Safe-Slowdown Power" v={p.pwr} max={100} unit="%" color={p.rel ? '#ef4444' : '#10b981'} />
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="card">
          <p className="lbl m-0">2x2 sensor grid</p>
          <div className="mt-3 grid grid-cols-2 gap-3">
            {[0, 1, 2, 3].map((i) => {
              const ghost = ((p.fl >> i) & 1) === 1;
              const dom = p.cl >= 1 && p.dom === i && !off;
              return (
                <div key={i} className="rounded-lg border-2 p-3" style={{borderColor: dom ? DOMINO : '#1e293b'}}>
                  <p className="lbl m-0">T{i + 1}</p>
                  <p className="m-0 font-mono text-xl">{(ghost ? recon(p.t, i) : p.t[i]).toFixed(1)}°C</p>
                  {ghost && <p className="m-0 text-xs text-warn">Ghost sensor: rebuilt from neighbors</p>}
                  {dom && <p className="m-0 text-xs" style={{color: DOMINO}}>Domino: next at risk</p>}
                </div>
              );
            })}
          </div>
        </div>
        <div className="card">
          <p className="lbl m-0">8x8 thermal surface</p>
          <div role="img" aria-label="8 by 8 thermal surface heatmap" className="mx-auto mt-3 grid max-w-[320px] grid-cols-8 gap-px" onMouseLeave={() => setHv(null)}>
            {hm.map((v, i) => (
              <div key={i} aria-hidden="true" onMouseEnter={() => setHv(i)} className="aspect-square" style={{background: heatColor(v), outline: hv === i ? '2px solid #fff' : an.has(i) ? '2px solid #ef4444' : undefined}} />
            ))}
          </div>
          <p className="mt-2 mb-0 text-center font-mono text-sm text-dust" aria-live="polite">{hv === null ? 'Hover a pixel' : `Pixel ${hv % 8},${Math.floor(hv / 8)}: ${hm[hv]}°C`}</p>
        </div>
      </div>

      <div className="card mt-6">
        <p className="lbl m-0">{edge.eyebrow}</p>
        <h3 className="text-lead mt-2">{edge.heading}</h3>
        <p className="mt-2 max-w-3xl text-dust">{edge.body}</p>
        <dl className="m-0 grid grid-cols-2 gap-4 font-mono md:grid-cols-4">
          {([['Threat score', `${p.sc}/100`], ['Rate of rise', `${p.r} °C/min`], ['Runaway forecast', p.ttr < 0 ? 'none' : `in ${p.ttr} s`], ['Anomalous pixels', p.hm ? String(an.size) : 'frame not sent']] as const).map(([k, v]) => (
            <div key={k}><dt className="lbl">{k}</dt><dd className="m-0 text-xl" style={{color: s.c}}>{v}</dd></div>
          ))}
        </dl>
        <p className="mt-4 mb-1 font-mono text-sm">Raw frame stream: 12,800 B per frame · Threat packet: {bytes} B · {saved}% saved</p>
        <div className="h-2 rounded bg-slate-800" role="img" aria-label={`Packet is ${saved} percent smaller than a raw frame`}><div className="h-2 rounded bg-ok" style={{width: `${Math.max(1, (bytes / 12800) * 100)}%`}} /></div>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Trend label="Core temperature (°C)" data={hist.map((h) => h.core)} max={100} color={s.c} />
        <Trend label="Gas (ppm)" data={hist.map((h) => h.gas)} max={2500} color="#6fb6ff" />
      </div>
      <button className="btn mt-6" onClick={download}>Download black-box event log (CSV)</button>

      <div className="mt-24 grid gap-6">
        {modules.map((m, i) => (
          <article key={m.title} ref={(el) => { reel.current[i] = el; }} data-focus="0" className="reel card">
            <p className="lbl m-0">{m.tag}</p>
            <h3 className="text-lead mt-2">{m.title}</h3>
            <p className="mt-2 mb-0 text-dust">{m.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
