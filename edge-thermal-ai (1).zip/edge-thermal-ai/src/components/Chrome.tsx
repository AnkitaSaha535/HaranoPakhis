import {useState, type MouseEvent} from 'react';
import {brand, nav} from '../content';
import {scrollToHash} from '../lib/scroll';

export function Header() {
  const [open, setOpen] = useState(false);
  const go = (h: string) => (e: MouseEvent) => {
    e.preventDefault();
    setOpen(false);
    scrollToHash(h);
  };
  return (
    <header className="fixed inset-x-0 top-0 z-50 bg-void/70 backdrop-blur">
      <div className="flex items-center justify-between px-5 py-4 md:px-10">
        <a href="#hero" onClick={go('#hero')} className="font-display text-xs tracking-[0.2em] text-sunlit">{brand.wordmark}</a>
        <nav aria-label="Primary" className="hidden gap-8 md:flex">
          {nav.map((n) => (
            <a key={n.href} href={n.href} onClick={go(n.href)} className="text-sm text-regolith hover:text-earth">{n.label}</a>
          ))}
        </nav>
        <button className="btn md:hidden" aria-expanded={open} aria-controls="drawer" aria-label="Toggle menu" onClick={() => setOpen(!open)}>
          {open ? 'Close' : 'Menu'}
        </button>
      </div>
      {open && (
        <nav id="drawer" aria-label="Mobile" className="flex flex-col gap-4 border-t border-slate-800 px-5 py-5 md:hidden">
          {nav.map((n) => (
            <a key={n.href} href={n.href} onClick={go(n.href)}>{n.label}</a>
          ))}
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-slate-800 px-5 py-10 text-center text-sm text-dust">
      <p className="font-display text-xs tracking-[0.2em] text-sunlit">{brand.wordmark}</p>
      <p className="mt-2">{brand.dropLine}</p>
      <p className="mt-1"><a href={`mailto:${brand.email}`} className="text-earth">{brand.email}</a></p>
    </footer>
  );
}
