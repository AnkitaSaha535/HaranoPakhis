import {useEffect, useState, type FormEvent} from 'react';
import {portal} from '../content';
import {BRIDGE, fnv, stateOf, useTelemetry} from '../lib/telemetry';

const ld = <T,>(k: string, d: T): T => {
  try {
    return JSON.parse(localStorage.getItem(k) ?? '') as T;
  } catch {
    return d;
  }
};
const sv = (k: string, v: unknown) => {
  try {
    localStorage.setItem(k, JSON.stringify(v));
  } catch {
    /* storage unavailable */
  }
};
const sha = async (s: string) => {
  const b = await crypto.subtle?.digest('SHA-256', new TextEncoder().encode(s));
  return b ? Array.from(new Uint8Array(b), (x) => x.toString(16).padStart(2, '0')).join('') : fnv(0x811c9dc5, s).toString(16);
};

export function DevicePortal() {
  const [me, setMe] = useState<string | null>(() => ld<string | null>('abr-me', null));
  const [tab, setTab] = useState<'up' | 'in'>('up');
  const [msg, setMsg] = useState('');
  const [devs, setDevs] = useState<string[]>([]);
  const [sel, setSel] = useState('');
  const {p, src, off} = useTelemetry();

  useEffect(() => {
    const d = me ? ld<string[]>('abr-dev-' + me, []) : [];
    setDevs(d);
    setSel(d[0] ?? '');
  }, [me]);

  const auth = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const em = String(f.get('email')).trim().toLowerCase();
    const h = await sha(String(f.get('pw')));
    const users = ld<Record<string, string>>('abr-users', {});
    if (tab === 'up') {
      if (users[em]) return setMsg('That email is already registered. Switch to Login.');
      users[em] = h;
      sv('abr-users', users);
    } else if (users[em] !== h) return setMsg('Email or password is incorrect.');
    sv('abr-me', em);
    setMe(em);
    setMsg('');
  };

  const pair = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const id = String(f.get('node')).trim().toLowerCase();
    if (!/^[a-z0-9-]{3,16}$/.test(id)) return setMsg('Node ID: 3–16 letters, numbers or dashes.');
    if (String(f.get('key')).trim().length < 6) return setMsg('Pairing key must be at least 6 characters.');
    if (devs.includes(id)) return setMsg('That node is already paired.');
    const d = [...devs, id];
    setDevs(d);
    setSel(id);
    sv('abr-dev-' + me, d);
    setMsg(`Paired ${id}.`);
    e.currentTarget.reset();
  };

  const mine = src === 'simulator' || p.id === sel;
  const s = stateOf(p.cl, off);
  const alerts = [
    p.gas >= 600 && `MQ-2 gas at ${p.gas} ppm`,
    p.core >= p.dl && `Core ${p.core}°C is over the ${p.dl}°C auto-limit`,
    p.rel === 1 && 'Relay tripped: load cut off',
    p.q > 0 && `${p.q} packets queued in ESP32 RAM`,
  ].filter(Boolean) as string[];

  return (
    <section id="portal" className="wrap">
      <div data-reveal>
        <p className="lbl">{portal.eyebrow}</p>
        <h2 className="text-display mt-3 max-w-3xl">{portal.heading}</h2>
      </div>
      <p className="mt-6 font-mono text-sm" role="status">
        Bridge: UDP 4210 → WebSocket {BRIDGE} · <b style={{color: src === 'bridge' ? '#10b981' : '#f59e0b'}}>{src === 'bridge' ? 'connected' : 'not found, using simulator'}</b>
      </p>
      <div className="mt-6 grid gap-6 md:grid-cols-2">
        {!me ? (
          <div className="card">
            <div role="tablist" className="mb-4 flex gap-2">
              <button role="tab" aria-selected={tab === 'up'} className="btn" onClick={() => setTab('up')}>Sign Up</button>
              <button role="tab" aria-selected={tab === 'in'} className="btn" onClick={() => setTab('in')}>Login</button>
            </div>
            <form onSubmit={auth} className="grid gap-3">
              <input className="field" name="email" type="email" required placeholder="Email" aria-label="Email" autoComplete="email" />
              <input className="field" name="pw" type="password" required minLength={8} placeholder="Password (8+ characters)" aria-label="Password" autoComplete={tab === 'up' ? 'new-password' : 'current-password'} />
              <button className="btn" type="submit">{tab === 'up' ? 'Create account' : 'Log in'}</button>
            </form>
            <p className="mt-3 mb-0 text-xs text-dust">{portal.note}</p>
          </div>
        ) : (
          <div className="card">
            <p className="m-0">Signed in as <b>{me}</b> <button className="btn ml-2" onClick={() => { sv('abr-me', null); setMe(null); }}>Log out</button></p>
            <form onSubmit={pair} className="mt-4 grid gap-3">
              <p className="lbl m-0">Add new device</p>
              <input className="field" name="node" required placeholder="Node ID (e.g. node1)" aria-label="Node ID" />
              <input className="field" name="key" type="password" required placeholder="Pairing key" aria-label="Pairing key" />
              <button className="btn" type="submit">Pair device</button>
            </form>
          </div>
        )}
        <div className="card">
          <p className="lbl m-0">Personal device monitor</p>
          {!me ? <p>Log in and pair a node to see its private readings.</p> : !devs.length ? <p>No devices yet. Pair your first ESP32 node.</p> : (
            <>
              <select className="field mt-2" value={sel} onChange={(e) => setSel(e.target.value)} aria-label="Paired device">
                {devs.map((d) => <option key={d}>{d}</option>)}
              </select>
              {mine ? (
                <div className="mt-3 font-mono">
                  <p className="m-0 text-2xl" style={{color: s.c}}>{s.n}</p>
                  <p className="m-0">Temp {Math.max(...p.t).toFixed(1)}°C · Gas {p.gas} ppm · Core {p.core}°C</p>
                  <p className="m-0 text-sm text-dust">Queue {p.q} · {src === 'simulator' ? 'simulated data' : 'live data'}</p>
                  <ul className="mt-2 pl-5 text-sm">{alerts.length ? alerts.map((a) => <li key={a}>{a}</li>) : <li>No alerts</li>}</ul>
                </div>
              ) : <p className="mt-3">Waiting for packets from {sel}…</p>}
            </>
          )}
        </div>
      </div>
      {msg && <p role="status" className="mt-4 text-warn">{msg}</p>}
    </section>
  );
}
