import {useEffect, useRef} from 'react';
import {pipeline} from '../content';
import {useReducedMotion} from '../hooks/useReducedMotion';
import {registerScrollHandler} from '../lib/scroll';

const SECTION_VH = 380;
const WINDOW = 0.85; // share of the pinned scroll spent inking the four legs
const X = [0, 125, 375, 625, 875];
const clamp = (v: number) => Math.min(1, Math.max(0, v));

export function Pipeline() {
  const root = useRef<HTMLElement>(null);
  const legs = useRef<(SVGLineElement | null)[]>([]);
  const pulse = useRef<SVGCircleElement>(null);
  const cards = useRef<(HTMLLIElement | null)[]>([]);
  const bw = useRef<HTMLSpanElement>(null);
  const reduced = useReducedMotion();

  useEffect(
    () =>
      registerScrollHandler((_y, vh) => {
        const el = root.current;
        if (!el) return;
        const p = reduced ? 1 : clamp(-el.getBoundingClientRect().top / (el.offsetHeight - vh));
        const w = clamp(p / WINDOW);
        legs.current.forEach((l, i) => l?.setAttribute('stroke-dashoffset', String(1 - clamp(w * 4 - i))));
        const leg = Math.min(3, Math.floor(w * 4));
        const f = clamp(w * 4 - leg);
        pulse.current?.setAttribute('cx', String(X[leg] + (X[leg + 1] - X[leg]) * f));
        pulse.current?.setAttribute('opacity', w > 0 ? '1' : '0');
        cards.current.forEach((c, i) => {
          if (c) c.dataset.on = w * 4 > i ? '1' : '0';
        });
        if (bw.current) bw.current.textContent = `${(98.5 * w).toFixed(1)}%`;
      }),
    [reduced],
  );

  return (
    <section id="pipeline" ref={root} className="relative" style={{height: `${SECTION_VH}vh`}}>
      <div className="sticky top-0 flex h-screen flex-col justify-center px-5 pt-16 md:px-10">
        <div className="mx-auto w-full max-w-5xl">
          <p className="lbl">{pipeline.eyebrow}</p>
          <h2 className="text-display mt-2">{pipeline.heading}</h2>
          <svg viewBox="0 0 1000 120" className="my-4 w-full" aria-hidden="true">
            {[0, 1, 2, 3].map((i) => (
              <line key={i} ref={(el) => { legs.current[i] = el; }} x1={X[i]} x2={X[i + 1]} y1="60" y2="60" stroke="#ef4444" strokeWidth="6" strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1} />
            ))}
            {X.slice(1).map((x) => <circle key={x} cx={x} cy="60" r="12" fill="#05070c" stroke="#6fb6ff" strokeWidth="3" />)}
            <circle ref={pulse} cx="0" cy="60" r="9" fill="#fff6d6" opacity="0" />
          </svg>
          <ol className="m-0 grid list-none grid-cols-2 gap-3 p-0 md:grid-cols-4">
            {pipeline.stages.map((s, i) => (
              <li key={s.title} ref={(el) => { cards.current[i] = el; }} data-on="0" className="stage card">
                <p className="lbl m-0">Stage {i + 1}</p>
                <h3 className="mt-1 text-xs leading-snug tracking-wider">{s.title}</h3>
                <p className="mt-2 mb-0 hidden text-sm text-dust md:block">{s.body}</p>
              </li>
            ))}
          </ol>
          <p className="mt-4 mb-0 font-mono"><span ref={bw} className="text-3xl text-ok">0.0%</span> <span className="text-sm text-dust">{pipeline.saved}</span></p>
        </div>
      </div>
    </section>
  );
}
