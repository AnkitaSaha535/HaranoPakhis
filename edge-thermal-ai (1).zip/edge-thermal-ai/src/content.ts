/**
 * Every word on the page. ActionBeforeReaction (Edge Thermal AI v2) —
 * decentralized ESP32 battery thermal runaway detection, active containment & telemetry.
 */
export const brand = {
  name: 'ActionBeforeReaction',
  wordmark: 'ACTION // BEFORE',
  dropLine: 'Act in microseconds. Leave thermal runaway on read.',
  email: 'ops@actionbeforereaction.ai',
};

export const nav = [
  {label: 'Live Demo', href: '#dashboard'},
  {label: 'Pipeline', href: '#pipeline'},
  {label: 'Arena', href: '#arena'},
  {label: 'Register Device', href: '#portal'},
];

export const hero = {
  title: ['ACT', 'BEFORE'],
  kicker: 'ActionBeforeReaction — Act in microseconds. Leave thermal runaway on read.',
  site: 'ESP32-WROOM · 4x NTC + MQ-2 · <300 µs INT8 Inference',
};

export const intro = {
  eyebrow: 'Live Public Dashboard (No Registration Required)',
  heading: 'Real-time thermal telemetry, straight from the edge.',
  body: 'Watch a live ESP32 node track Inside-Core X-Ray heat, MQ-2 gas venting, Ghost Sensor reconstruction, and Domino heat-spread risk — no login needed.',
};

export const modules = [
  {tag: 'INT8 Edge AI', title: 'Inside-Core X-Ray', body: 'Estimates internal cell temperature ahead of surface skin lag and computes Threat Score (0–100) in under 300 microseconds.'},
  {tag: 'Fault-Tolerant', title: 'Ghost & Domino Map', body: 'Reconstructs failed NTC sensors from neighbors and flags the next adjacent cell at risk of thermal propagation.'},
  {tag: 'Active Safety', title: 'Valve & Relay Cutoff', body: 'Proportional cooling servo (0°–180°), Safe-Slowdown power throttling, and instant hardware relay cutoff on CRITICAL.'},
  {tag: 'Tamper-Evident', title: 'microSD Black-Box', body: 'Hash-chained local CSV logging with offline RAM queue failover that auto-syncs to the dashboard when Wi-Fi returns.'},
];

/** Legs of the autonomous edge safety pipeline, in drawing order. */
export const pipeline = {
  eyebrow: 'Autonomous Pipeline',
  heading: 'Sense to cutoff in <300 µs, drawn as you scroll.',
  saved: 'Bandwidth saved vs. streaming raw 12,800-byte thermal frames',
  stages: [
    {title: 'Multi-Sensor Fusion', body: '4x NTC surface temperatures, MQ-2 gas and rate of rise merge into one state.'},
    {title: 'On-Device INT8 Inference', body: 'A quantized model returns a Threat Score and state class in ~230–305 µs.'},
    {title: 'Proportional Cooling & Throttle', body: 'The servo pre-cools near 30°, opens in proportion during WARNING, and Safe-Slowdown trims load power.'},
    {title: 'Relay Cutoff & Black-Box Seal', body: 'CRITICAL trips the relay, opens the valve to 180° and seals the event in the FNV-1a hash chain.'},
  ],
};

export type Q = {q: string; o: string[]; a: number; why: string};

export const arena = {
  eyebrow: 'Learning Arena',
  heading: 'Learn how heat becomes failure — then stop it.',
  body: 'Hold a rising cell below CRITICAL, test what you know about the sensors, then read a real-looking black-box log.',
};

export const labQuiz: Q[] = [
  {q: 'An NTC thermistor heats up. What happens to its resistance?', o: ['It falls', 'It rises', 'It stays constant'], a: 0, why: 'NTC means negative temperature coefficient: resistance drops as temperature rises, which the ESP32 reads as a voltage change.'},
  {q: 'T1 disconnects and reads garbage. What keeps safety decisions running?', o: ['Ghost Sensor reconstruction from neighboring cells', 'Rebooting the ESP32', 'Ignoring T1 forever'], a: 0, why: 'The firmware flags the channel in the fl bitmask and rebuilds that cell from healthy neighbors.'},
  {q: 'Why fit an MQ-2 gas sensor?', o: ['It catches electrolyte off-gassing before visible ignition', 'It measures pack voltage', 'It drives the cooling servo'], a: 0, why: 'Venting gas often shows up before the surface gets hot.'},
  {q: 'Which part is the final hardware cutoff on CRITICAL?', o: ['Piezo buzzer', 'Active-LOW PNP relay', 'SSD1306 OLED'], a: 1, why: 'The relay trips and drops the load; the buzzer and OLED only warn.'},
];

export const forensicsQuiz: Q[] = [
  {q: 'Row: t=[24,24,24,24] core=25 gas=1850 cl=2. What kind of anomaly is this?', o: ['Gas venting', 'Heat runaway', 'Sensor fault'], a: 0, why: 'Surfaces are cool but gas is far above the limit, so venting triggered CRITICAL.'},
  {q: 'Row: t=[24,24,61,31] core=72 gas=210 dom=3. What does dom=3 flag?', o: ['Bottom-right cell as next at risk', 'Top-left cell has failed', 'The relay is open'], a: 0, why: 'dom is the cell index (0–3) most likely to heat next; cell 3 sits beside the hot bottom-left cell.'},
  {q: 'Row 14\'s hash does not match FNV-1a of row 13 plus its data. What happened?', o: ['The log was altered or corrupted', 'Wi-Fi dropped', 'Normal operation'], a: 0, why: 'Each row chains the previous hash, so one edited row breaks every row after it.'},
  {q: 'Packets with sync=1 and q=7 arrive once Wi-Fi returns. What are they?', o: ['Readings replayed from the ESP32 RAM queue', 'A new sensor fault', 'A relay trip'], a: 0, why: 'While offline the node queues telemetry in RAM and flushes it after reconnecting.'},
];

export const portal = {
  eyebrow: 'User Portal',
  heading: 'Pair your own ESP32 and watch it live.',
  note: 'Demo accounts live in this browser only. Connect a backend before storing real credentials.',
};

export const edge = {
  eyebrow: 'Edge Analyzer',
  heading: 'The node reads the thermal array. The dashboard only gets the verdict.',
  body: 'Each second the ESP32 scans the 2D thermal array on the device, flags pixels that stand out, forecasts time to runaway from the rate of rise, and sends a lightweight threat score. The full frame is sent only on WARNING or CRITICAL. Red-outlined pixels below are on-device anomalies.',
};
