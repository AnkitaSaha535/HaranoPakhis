import {useEffect} from 'react';
import {Footer, Header} from './components/Chrome';
import {DevicePortal} from './components/DevicePortal';
import {LearningArena} from './components/LearningArena';
import {LiveDashboard} from './components/LiveDashboard';
import {Pipeline} from './components/Pipeline';
import {ThermalHero} from './components/ThermalHero';
import {useReducedMotion} from './hooks/useReducedMotion';
import {startScroll} from './lib/scroll';

export default function App() {
  const reduced = useReducedMotion();
  useEffect(() => startScroll(reduced), [reduced]);
  return (
    <>
      <Header />
      <main>
        <ThermalHero />
        <LiveDashboard />
        <Pipeline />
        <LearningArena />
        <DevicePortal />
      </main>
      <Footer />
    </>
  );
}
