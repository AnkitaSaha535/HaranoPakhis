/**
 * Edge analyzer: the project challenge. It reads a 2D thermal array locally, flags
 * anomalies, forecasts thermal runaway and returns a lightweight threat score, so
 * only a small packet (not the raw frame) goes to the central dashboard.
 * Mirrors firmware/edge_analyzer.h, so the web demo behaves like the ESP32.
 */
export const N = 8;
export const RUNAWAY_C = 70;
/** Neighbors in the 2x2 cell layout (0 TL, 1 TR, 2 BL, 3 BR). */
export const ADJ = [[1, 2], [0, 3], [0, 3], [1, 2]];
const clamp = (v: number) => Math.min(1, Math.max(0, v));

export type Analysis = {
  max: number; core: number; rate: number; ttr: number; grad: number;
  sc: number; cl: number; dom: number; anomalies: number[];
};

/** Pixels that stand out from their 4-neighbors (>5 °C) or from the frame mean (>8 °C). */
export function findAnomalies(f: number[]) {
  const mean = f.reduce((a, b) => a + b, 0) / f.length;
  const out: number[] = [];
  f.forEach((v, i) => {
    const x = i % N, y = Math.floor(i / N);
    const nb = [x > 0 && f[i - 1], x < N - 1 && f[i + 1], y > 0 && f[i - N], y < N - 1 && f[i + N]].filter((n): n is number => n !== false);
    const avg = nb.reduce((a, b) => a + b, 0) / nb.length;
    if (v - avg > 5 || v - mean > 8) out.push(i);
  });
  return out;
}

export class EdgeAnalyzer {
  private prevMax = NaN;
  private prevT = 0;
  private rate = 0;
  private score = 0;
  private last: Analysis | null = null;

  /** One frame in (°C, row-major N*N) plus gas ppm; one Analysis out. Call about once a second. */
  analyze(f: number[], gas: number, now = Date.now() / 1000): Analysis {
    const dt = now - this.prevT;
    if (this.last && dt < 0.5) return this.last;

    const max = Math.max(...f);
    let grad = 0; // steepest spatial gradient between adjacent pixels
    f.forEach((v, i) => {
      if (i % N < N - 1) grad = Math.max(grad, Math.abs(v - f[i + 1]));
      if (i < N * (N - 1)) grad = Math.max(grad, Math.abs(v - f[i + N]));
    });
    if (!Number.isNaN(this.prevMax)) this.rate = 0.6 * this.rate + 0.4 * (((max - this.prevMax) / dt) * 60); // °C/min, smoothed
    this.prevMax = max;
    this.prevT = now;

    const anomalies = findAnomalies(f);
    const core = max + Math.min(80, Math.max(0, this.rate)) * 0.15; // core runs ahead of surface skin
    const ttr = this.rate > 1 && core < RUNAWAY_C ? Math.round(((RUNAWAY_C - core) / this.rate) * 60) : -1;
    const raw =
      100 * (0.35 * clamp((core - 30) / (RUNAWAY_C - 30)) + 0.25 * clamp(this.rate / 60) + 0.15 * clamp(grad / 15) + 0.1 * clamp(anomalies.length / 8) + 0.15 * clamp(gas / 2000));
    this.score = Math.max(raw, this.score * 0.92); // decays slowly so a spike is not forgotten at once
    const sc = Math.round(Math.min(100, ttr >= 0 && ttr <= 30 ? Math.max(this.score, 70) : this.score));
    const cl = core >= RUNAWAY_C || gas >= 1800 || sc >= 70 ? 2 : sc >= 35 ? 1 : 0;

    // Domino: the cell next to the hottest quadrant that is warmest.
    const q = [0, 0, 0, 0], h = N / 2;
    f.forEach((v, i) => {
      q[(Math.floor(i / N) >= h ? 2 : 0) + (i % N >= h ? 1 : 0)] += v / (h * h);
    });
    const dom = ADJ[q.indexOf(Math.max(...q))].reduce((a, b) => (q[b] > q[a] ? b : a));

    this.last = {max, core: +core.toFixed(1), rate: +this.rate.toFixed(1), ttr, grad: +grad.toFixed(1), sc, cl, dom, anomalies};
    return this.last;
  }
}
