import {useEffect, useState} from 'react';
import {ADJ, EdgeAnalyzer} from './edge';

export {ADJ};

export type Packet = {
  id: string; up: number; t: number[]; r: number; sc: number; cl: number; fl: number; us: number;
  core: number; gas: number; pwr: number; rel: number; srv: number; dom: number; dna: number;
  ttr: number; dl: number; sw: number; hs: string; sd: number; q: number; hm?: number[]; sync?: number;
};

export const STATES = [
  {n: 'NORMAL', c: '#10b981'},
  {n: 'WARNING', c: '#f59e0b'},
  {n: 'CRITICAL', c: '#ef4444'},
];
export const OFFLINE = {n: 'OFFLINE', c: '#64748b'};
export const DOMINO = '#c084fc';
export const stateOf = (cl: number, off: boolean) => (off ? OFFLINE : STATES[cl] ?? STATES[0]);
export const recon = (t: number[], i: number) => ADJ[i].reduce((s, j) => s + t[j], 0) / 2;

export const fnv = (h: number, s: string) => {
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
};

/** Bilinear 8x8 surface from the 2x2 array. */
export const grid8 = (t: number[]) =>
  Array.from({length: 64}, (_, i) => {
    const x = (i % 8) / 7, y = Math.floor(i / 8) / 7;
    return Math.round((t[0] * (1 - x) + t[1] * x) * (1 - y) + (t[2] * (1 - x) + t[3] * x) * y);
  });
export const heatColor = (v: number) => `hsl(${Math.min(240, Math.max(0, 240 - (v - 20) * 4.5))} 85% 50%)`;

export const BRIDGE = new URLSearchParams(location.search).get('bridge') ?? 'ws://localhost:8765';

const analyzer = new EdgeAnalyzer();
let hash = 0x811c9dc5, sdCount = 0;

/** 180 s demo cycle on a raw 8x8 thermal frame: calm, one cell heats, runaway, cool-down. */
export function simulate(id = 'node1'): Packet {
  const now = Date.now() / 1000;
  const ph = (now % 180) / 180;
  const heat = ph < 0.2 ? 0 : ph < 0.7 ? (ph - 0.2) / 0.5 : Math.max(0, 1 - (ph - 0.7) / 0.3);
  const base = 24 + Math.sin(now / 7) * 0.4;
  const blob = (x: number, y: number, amp: number, cx: number, cy: number) => amp * Math.exp(-((x - cx) ** 2 + (y - cy) ** 2) / 6.5);
  const frame = Array.from({length: 64}, (_, i) => {
    const x = i % 8, y = Math.floor(i / 8);
    return +(base + blob(x, y, 46 * heat, 1.5, 5.5) + blob(x, y, 12 * heat, 5.5, 5.5) + (Math.random() - 0.5) * 0.6).toFixed(1);
  });
  const gas = Math.round(120 + heat ** 2 * 2300 + Math.random() * 30);
  // Analysis runs on the ESP32 in firmware; only this lightweight result goes upstream.
  const a = analyzer.analyze(frame, gas, now);
  const t = [frame[9], frame[14], frame[49], frame[54]]; // the four NTC positions
  const fl = now % 150 > 130 ? 1 : 0;
  if (fl) t[0] = -127;
  const cl = a.cl;
  hash = fnv(hash, `${a.core}${gas}${cl}`);
  if (cl) sdCount++;
  return {
    id, up: Math.round(now % 100000), t, r: a.rate, cl, fl, core: a.core, gas, dom: a.dom, sc: a.sc, ttr: a.ttr,
    us: 230 + Math.round(Math.random() * 75),
    pwr: cl === 2 ? 0 : cl === 1 ? 60 : 100,
    rel: cl === 2 ? 1 : 0,
    srv: cl === 2 ? 180 : cl === 1 ? Math.max(30, Math.min(150, Math.round(60 + (a.core - 45) * 5))) : heat > 0.05 ? 30 : 0,
    dna: +(heat * 9 + Math.random() * 0.3).toFixed(1),
    dl: cl ? 45 : 50,
    sw: frame.filter((v) => v > 40).length,
    hs: hash.toString(16).toUpperCase().padStart(8, '0'),
    sd: sdCount, q: 0,
    hm: cl > 0 ? frame.map((v) => Math.round(v)) : undefined, // full frame only on WARNING / CRITICAL
  };
}

/** Live WebSocket bridge (UDP 4210 → WS); falls back to the simulator when no bridge answers. */
export function useTelemetry(url = BRIDGE) {
  const [p, setP] = useState<Packet>(() => simulate());
  const [hist, setHist] = useState<Packet[]>([]);
  const [log, setLog] = useState<Packet[]>([]);
  const [src, setSrc] = useState<'bridge' | 'simulator'>('simulator');
  const [off, setOff] = useState(false);

  useEffect(() => {
    let ws: WebSocket | null = null, last = 0, live = false;
    const push = (k: Packet) => {
      last = Date.now();
      setOff(false);
      setP(k);
      setHist((h) => [...h.slice(-59), k]);
      if (k.cl > 0) setLog((l) => [...l.slice(-199), k]);
    };
    const down = () => {
      live = false;
      setSrc('simulator');
    };
    try {
      ws = new WebSocket(url);
      ws.onopen = () => {
        live = true;
        last = Date.now();
        setSrc('bridge');
      };
      ws.onmessage = (e) => {
        try {
          push(JSON.parse(e.data) as Packet);
        } catch {
          /* ignore malformed packet */
        }
      };
      ws.onclose = down;
      ws.onerror = down;
    } catch {
      down();
    }
    const iv = setInterval(() => {
      if (!live) push(simulate());
      else if (Date.now() - last > 5000) setOff(true);
    }, 1000);
    return () => {
      clearInterval(iv);
      ws?.close();
    };
  }, [url]);

  return {p, hist, log, src, off};
}
