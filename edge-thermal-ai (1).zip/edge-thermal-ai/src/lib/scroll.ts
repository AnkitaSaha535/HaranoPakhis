import Lenis from 'lenis';

type Handler = (y: number, vh: number) => void;
const handlers = new Set<Handler>();
let lenis: Lenis | null = null;

/** Components register a function that reads scroll position and writes styles directly. */
export function registerScrollHandler(h: Handler) {
  handlers.add(h);
  h(window.scrollY, innerHeight);
  return () => {
    handlers.delete(h);
  };
}

export function scrollToHash(hash: string) {
  const el = document.querySelector<HTMLElement>(hash);
  if (!el) return;
  if (lenis) lenis.scrollTo(el);
  else el.scrollIntoView();
}

/** The page's single rAF loop: advances Lenis, then every registered handler. */
export function startScroll(reduced: boolean) {
  lenis = reduced ? null : new Lenis({lerp: 0.1});
  let raf = 0;
  const tick = (t: number) => {
    lenis?.raf(t);
    handlers.forEach((h) => h(window.scrollY, innerHeight));
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
  const io = new IntersectionObserver(
    (es) => es.forEach((e) => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    }),
    {threshold: 0.15},
  );
  document.querySelectorAll('[data-reveal]').forEach((el) => io.observe(el));
  return () => {
    cancelAnimationFrame(raf);
    io.disconnect();
    lenis?.destroy();
    lenis = null;
  };
}
