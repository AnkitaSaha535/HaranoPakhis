// Edge analyzer for ESP32: one 8x8 thermal frame -> anomalies, runaway forecast, threat score.
// Same algorithm as src/lib/edge.ts. Call analyze() about once a second, then send only
// {"sc":..,"cl":..,"ttr":..,"core":..,"dom":..} over UDP 4210 (add "hm" only when cl >= 1).
#pragma once
#include <math.h>
#include <stdint.h>
#define EN 8
#define RUNAWAY_C 70.0f

struct Analysis { float maxT, core, rate; int ttr, score, state, dom, anomalies; };

class EdgeAnalyzer {
  float prevMax = NAN, rate = 0, score = 0;
  uint32_t prevMs = 0;
  static float c01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
 public:
  Analysis analyze(const float f[EN * EN], float gas, uint32_t nowMs) {
    float mx = f[0], mean = 0, grad = 0;
    for (int i = 0; i < EN * EN; i++) { if (f[i] > mx) mx = f[i]; mean += f[i] / (EN * EN); }
    int anomalies = 0;
    for (int i = 0; i < EN * EN; i++) {
      int x = i % EN, y = i / EN, n = 0; float s = 0;
      if (x > 0) { s += f[i - 1]; n++; }  if (x < EN - 1) { s += f[i + 1]; n++; }
      if (y > 0) { s += f[i - EN]; n++; } if (y < EN - 1) { s += f[i + EN]; n++; }
      if (x < EN - 1) grad = fmaxf(grad, fabsf(f[i] - f[i + 1]));
      if (y < EN - 1) grad = fmaxf(grad, fabsf(f[i] - f[i + EN]));
      if (f[i] - s / n > 5 || f[i] - mean > 8) anomalies++;
    }
    float dt = (nowMs - prevMs) / 1000.0f;
    if (!isnan(prevMax) && dt > 0) rate = 0.6f * rate + 0.4f * ((mx - prevMax) / dt) * 60;
    prevMax = mx; prevMs = nowMs;
    float core = mx + fminf(80, fmaxf(0, rate)) * 0.15f;
    int ttr = (rate > 1 && core < RUNAWAY_C) ? (int)((RUNAWAY_C - core) / rate * 60) : -1;
    float raw = 100 * (0.35f * c01((core - 30) / (RUNAWAY_C - 30)) + 0.25f * c01(rate / 60) + 0.15f * c01(grad / 15) + 0.1f * c01(anomalies / 8.0f) + 0.15f * c01(gas / 2000));
    score = fmaxf(raw, score * 0.92f);
    int sc = (int)fminf(100, (ttr >= 0 && ttr <= 30) ? fmaxf(score, 70) : score);
    int cl = (core >= RUNAWAY_C || gas >= 1800 || sc >= 70) ? 2 : (sc >= 35 ? 1 : 0);
    float q[4] = {0, 0, 0, 0};
    for (int i = 0; i < EN * EN; i++) q[((i / EN) >= EN / 2 ? 2 : 0) + ((i % EN) >= EN / 2 ? 1 : 0)] += f[i] / 16;
    int hot = 0; for (int k = 1; k < 4; k++) if (q[k] > q[hot]) hot = k;
    static const int adj[4][2] = {{1, 2}, {0, 3}, {0, 3}, {1, 2}};
    int dom = q[adj[hot][1]] > q[adj[hot][0]] ? adj[hot][1] : adj[hot][0];
    return {mx, core, rate, ttr, sc, cl, dom, anomalies};
  }
};
