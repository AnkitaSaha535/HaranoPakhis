# ActionBeforeReaction (Edge Thermal AI v2)

    npm install
    npm run dev      # http://localhost:3006
    npm run lint && npm run build

The dashboard connects to `ws://localhost:8765` (override with `?bridge=ws://host:port`) and expects the ESP32 JSON packet from the spec. If no bridge answers, a built-in simulator cycles NORMAL → WARNING → CRITICAL → cool-down. Portal accounts are demo-only (browser localStorage).

## Edge analyzer (the challenge)

`src/lib/edge.ts` analyses a 2D thermal array locally: anomaly pixels (neighbor and frame-mean outliers), smoothed rate of rise, forecast time to runaway, Inside-Core X-Ray estimate, Domino cell, and a 0-100 threat score. Only that lightweight result is sent to the dashboard; the 64-value frame goes up only on WARNING / CRITICAL. `firmware/edge_analyzer.h` is the same algorithm in C++ for the ESP32 (call `analyze()` about once a second). The weights and thresholds are hand-tuned demo values, not the trained INT8 model.
