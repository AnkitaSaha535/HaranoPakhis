#pragma once
#include <stdint.h>

#define MODEL_F 5
#define MODEL_H 12
#define MODEL_C 3

static const int8_t W1Q[12][5] = {
  {100,   0,   0,   0,   0},
  {  0,   0, 100,   0,   0},
  {  0,   0,   0, 100,   0},
  {  0,   0,   0,   0, 100},
  {  0, 100,   0,   0,   0},
  {  0,   0,   0,   0,   0},
  {  0,   0,   0,   0,   0},
  {  0,   0,   0,   0,   0},
  {  0,   0,   0,   0,   0},
  {  0,   0,   0,   0,   0},
  {  0,   0,   0,   0,   0},
  {  0,   0,   0,   0,   0}
};

static const int32_t B1Q[12] = {-6350, -5080, -3175, -3175, -5080, 0, 0, 0, 0, 0, 0, 0};

static const int8_t W2Q[3][12] = {
  {-10, -10, -10, -10, -10, 0, 0, 0, 0, 0, 0, 0},
  { 40,  30,  30,  30,  30, 0, 0, 0, 0, 0, 0, 0},
  {105,  20,  20,  20,  20, 0, 0, 0, 0, 0, 0, 0}
};

static const int32_t B2Q[3] = {500, -100, -220};

static const float M1 = 0.01f;
static const float M2 = 0.01f;

#define N_TESTS 4
static const float TEST_T[N_TESTS][4] = {
  {28.0f, 29.0f, 28.0f, 29.0f},
  {52.0f, 40.0f, 38.0f, 36.0f},
  {72.0f, 55.0f, 50.0f, 48.0f},
  {36.0f, 35.0f, 36.0f, 35.0f}
};
static const float TEST_RATE[N_TESTS] = {0.2f, 2.0f, 12.0f, 7.0f};
static const uint8_t TEST_CLASS[N_TESTS] = {0, 1, 2, 1};