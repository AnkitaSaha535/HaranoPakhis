#include <WiFi.h>
#include <WiFiUdp.h>
#include <math.h>
#include <string.h>
#include "model.h"

#define SIM_MODE        1
#define NODE_ID         "node1"
#define UDP_PORT        4210
#define HOME_SSID       "YOUR_WIFI_NAME"
#define HOME_PASS       "YOUR_WIFI_PASSWORD"
#define DASH_HOST       ""
#define SIM_DASH_HOST   ""
#define NTC_LOW_SIDE    1
#define BUZZ_ACTIVE_LOW 0
#define HARD_CRIT_C     65.0f

float offs[4] = {0.0f, 0.0f, 0.0f, 0.0f};

#if SIM_MODE
  #define WIFI_SSID_USED "Wokwi-GUEST"
  #define WIFI_PASS_USED ""
  #define DASH_HOST_USED SIM_DASH_HOST
  #define AUTOZERO_ON    0
#else
  #define WIFI_SSID_USED HOME_SSID
  #define WIFI_PASS_USED HOME_PASS
  #define DASH_HOST_USED DASH_HOST
  #define AUTOZERO_ON    1
#endif

const uint8_t PIN_T[4] = {33, 32, 35, 34};
const uint8_t PIN_BUZZ = 25;
const uint8_t PIN_LED  = 26;

const float BETA = 3950.0f, R_FIXED = 10000.0f, R_NOM = 10000.0f, T_NOM_K = 298.15f;
const uint16_t FAULT_LO = 40, FAULT_HI = 4055;

const uint8_t  NS = 20;
const uint16_t SAMPLE_MS = 25;
const float    FRAME_S = 0.5f;
const float    EMA_A = 0.4f;
const uint8_t  HN = 20;
const uint16_t TELEMETRY_MS = 1000;
const uint8_t  UP_FRAMES = 2, DOWN_FRAMES = 6;
const uint8_t  AUTOZERO_FRAMES = 10;

const char* STATE_NAME[3] = {"NORMAL", "WARNING", "CRITICAL"};

uint16_t sbuf[4][NS];
uint8_t  sIdx = 0;
uint32_t tSample = 0, tTelem = 0;
float    tf[4] = {25, 25, 25, 25};
bool     tfInit = false;
float    hist[HN];
uint8_t  hCount = 0, hIdx = 0;
uint8_t  state = 0, upCnt = 0, dnCnt = 0;
bool     stateChanged = false;
float    lastRate = 0;
int      lastScore = 0;
uint8_t  lastFault = 0;
uint32_t lastInferUs = 0;
float    azSum[4] = {0, 0, 0, 0};
uint8_t  azFrames = 0;

WiFiUDP   udp;
IPAddress dashIP;
bool      dashResolved = false;

static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int   clampi(int v, int lo, int hi)       { return v < lo ? lo : (v > hi ? hi : v); }

void makeFeatures(const float T[4], float rate, float f[MODEL_F]) {
  float tmax = T[0], tmin = T[0], sum = 0;
  for (int i = 0; i < 4; i++) {
    if (T[i] > tmax) tmax = T[i];
    if (T[i] < tmin) tmin = T[i];
    sum += T[i];
  }
  float tmean = sum / 4.0f;
  f[0] = clampf((tmax - 25.0f) / 50.0f, -1, 1);
  f[1] = clampf((tmean - 25.0f) / 50.0f, -1, 1);
  f[2] = clampf((tmax - tmin) / 25.0f, -1, 1);
  f[3] = clampf(rate / 10.0f, -1, 1);
  f[4] = clampf((tmax - tmean) / 10.0f, -1, 1);
}

void infer(const float f[MODEL_F], float p[MODEL_C]) {
  int8_t xq[MODEL_F], hq[MODEL_H];
  for (int i = 0; i < MODEL_F; i++)
    xq[i] = (int8_t)clampi((int)lrintf(f[i] * 127.0f), -127, 127);

  for (int j = 0; j < MODEL_H; j++) {
    int32_t acc = B1Q[j];
    for (int i = 0; i < MODEL_F; i++) acc += (int32_t)W1Q[j][i] * xq[i];
    hq[j] = (int8_t)clampi((int)lrintf((float)acc * M1), 0, 127);
  }

  float z[MODEL_C], zmax = -1e30f;
  for (int k = 0; k < MODEL_C; k++) {
    int32_t acc = B2Q[k];
    for (int j = 0; j < MODEL_H; j++) acc += (int32_t)W2Q[k][j] * hq[j];
    z[k] = (float)acc * M2;
    if (z[k] > zmax) zmax = z[k];
  }

  float s = 0;
  for (int k = 0; k < MODEL_C; k++) { p[k] = expf(z[k] - zmax); s += p[k]; }
  for (int k = 0; k < MODEL_C; k++) p[k] /= s;
}

int argmax(const float* p, int n) {
  int b = 0;
  for (int i = 1; i < n; i++) if (p[i] > p[b]) b = i;
  return b;
}

void selfTest() {
  bool ok = true;
  for (int k = 0; k < N_TESTS; k++) {
    float f[MODEL_F], p[MODEL_C];
    makeFeatures(TEST_T[k], TEST_RATE[k], f);
    infer(f, p);
    int c = argmax(p, MODEL_C);
    Serial.printf("[selftest %d] expect %s, got %s\n", k + 1, STATE_NAME[TEST_CLASS[k]], STATE_NAME[c]);
    if (c != TEST_CLASS[k]) ok = false;
  }
  Serial.println(ok ? "[selftest] PASS - model loaded correctly"
                    : "[selftest] FAIL - re-run train_model.py and copy the new model.h");
}
float rawToC(uint16_t raw) {
  float r = (float)raw;
  float rn = NTC_LOW_SIDE ? R_FIXED * r / (4095.0f - r) : R_FIXED * (4095.0f - r) / r;
  return 1.0f / (logf(rn / R_NOM) / BETA + 1.0f / T_NOM_K) - 273.15f;
}

uint16_t medianFrame(const uint16_t* a) {
  uint16_t t[NS];
  memcpy(t, a, sizeof(t));
  for (int i = 1; i < NS; i++) {
    uint16_t v = t[i];
    int j = i - 1;
    while (j >= 0 && t[j] > v) { t[j + 1] = t[j]; j--; }
    t[j + 1] = v;
  }
  return (uint16_t)(((uint32_t)t[NS / 2 - 1] + t[NS / 2]) / 2);
}

void processFrame() {
  float tc[4];
  uint8_t fault = 0, nValid = 0;
  float sumValid = 0;
  for (int i = 0; i < 4; i++) {
    uint16_t raw = medianFrame(sbuf[i]);
    if (raw < FAULT_LO || raw > FAULT_HI) { fault |= (1 << i); tc[i] = 0; }
    else { tc[i] = rawToC(raw) + offs[i]; sumValid += tc[i]; nValid++; }
  }
  lastFault = fault;

  int cls;
  float p[MODEL_C] = {1, 0, 0};
  float tmax = tf[0];

  if (nValid == 0) {
    cls = 1; lastScore = 50; lastRate = 0; lastInferUs = 0;
  } else {
    float avg = sumValid / nValid;
    for (int i = 0; i < 4; i++) if (fault & (1 << i)) tc[i] = avg;

#if AUTOZERO_ON
    if (azFrames < AUTOZERO_FRAMES && fault == 0) {
      for (int i = 0; i < 4; i++) azSum[i] += tc[i];
      if (++azFrames == AUTOZERO_FRAMES) {
        float g = 0;
        for (int i = 0; i < 4; i++) g += azSum[i] / azFrames;
        g /= 4.0f;
        for (int i = 0; i < 4; i++) {
          float d = g - azSum[i] / azFrames;
          if (fabsf(d) < 3.0f) offs[i] += d;
        }
        Serial.printf("[autozero done, offsets %.2f %.2f %.2f %.2f]\n", offs[0], offs[1], offs[2], offs[3]);
      }
    }
#endif

    if (!tfInit) { for (int i = 0; i < 4; i++) tf[i] = tc[i]; tfInit = true; }
    else         { for (int i = 0; i < 4; i++) tf[i] += EMA_A * (tc[i] - tf[i]); }

    tmax = tf[0];
    for (int i = 1; i < 4; i++) if (tf[i] > tmax) tmax = tf[i];
    hist[hIdx] = tmax;
    hIdx = (hIdx + 1) % HN;
    if (hCount < HN) hCount++;
    uint8_t oldest = (hCount == HN) ? hIdx : 0;
    uint8_t span = hCount - 1;
    lastRate = (span < 4) ? 0.0f : clampf((tmax - hist[oldest]) / (span * FRAME_S) * 60.0f, -30.0f, 30.0f);

    float f[MODEL_F];
    makeFeatures(tf, lastRate, f);
    uint32_t t0 = micros();
    infer(f, p);
    lastInferUs = micros() - t0;
    cls = argmax(p, MODEL_C);
    lastScore = clampi((int)lrintf(100.0f * (0.5f * p[1] + p[2])), 0, 100);
  }

  bool hard = (nValid > 0 && tmax >= HARD_CRIT_C);
  if (hard) { cls = 2; lastScore = 100; }

  uint8_t prev = state;
  if (hard)             { state = 2; upCnt = dnCnt = 0; }
  else if (cls > state) { dnCnt = 0; if (++upCnt >= UP_FRAMES)   { state = cls; upCnt = 0; } }
  else if (cls < state) { upCnt = 0; if (++dnCnt >= DOWN_FRAMES) { state = cls; dnCnt = 0; } }
  else                  { upCnt = dnCnt = 0; }
  if (state != prev) stateChanged = true;

  Serial.printf("[%.1f %.1f %.1f %.1f] max=%.1f rate=%.1f/min score=%d %s AI=%luus%s\n",
    tf[0], tf[1], tf[2], tf[3], tmax, lastRate, lastScore, STATE_NAME[state],
    (unsigned long)lastInferUs, fault ? " SENSOR_FAULT" : "");
}

bool buzzNow = false;
void setBuzzer(bool on) {
  if (on == buzzNow) return;
  buzzNow = on;
#if SIM_MODE && defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  if (on) tone(PIN_BUZZ, 2000); else noTone(PIN_BUZZ);
#else
  digitalWrite(PIN_BUZZ, (on ^ (bool)BUZZ_ACTIVE_LOW) ? HIGH : LOW);
#endif
}

void updateAlarm() {
  uint32_t now = millis();
  bool led = false, bz = false;
  if (state == 2)      { led = true;                   bz = ((now / 125) % 2) == 0; }
  else if (state == 1) { led = ((now / 500) % 2) == 0; bz = (now % 2000) < 100; }
  else if (lastFault)  { led = ((now / 200) % 2) == 0; }
  digitalWrite(PIN_LED, led ? HIGH : LOW);
  setBuzzer(bz);
}

void wifiBegin() {
#if SIM_MODE
  WiFi.begin(WIFI_SSID_USED, WIFI_PASS_USED, 6);
#else
  WiFi.begin(WIFI_SSID_USED, WIFI_PASS_USED);
#endif
}

void wifiService() {
  static uint32_t lastTry = 0;
  static bool announced = false;
  if (WiFi.status() == WL_CONNECTED) {
    if (!announced) {
      announced = true;
      Serial.print("[wifi] connected, IP ");
      Serial.println(WiFi.localIP());
    }
    return;
  }
  announced = false;
  dashResolved = false;
  if (millis() - lastTry > 10000) {
    lastTry = millis();
    WiFi.disconnect();
    wifiBegin();
  }
}

void resolveDash() {
  static uint32_t last = 0;
  if (dashResolved || WiFi.status() != WL_CONNECTED) return;
  if (last && millis() - last < 30000) return;
  last = millis();
  const char* host = DASH_HOST_USED;
  if (host[0] == 0)            { dashIP = WiFi.broadcastIP(); dashResolved = true; return; }
  if (dashIP.fromString(host)) { dashResolved = true; return; }
  dashResolved = WiFi.hostByName(host, dashIP);
}

void sendTelemetry() {
  if (WiFi.status() != WL_CONNECTED || !dashResolved) return;
  char buf[176];
  int n = snprintf(buf, sizeof(buf),
    "{\"id\":\"%s\",\"up\":%lu,\"t\":[%.1f,%.1f,%.1f,%.1f],\"r\":%.1f,\"sc\":%d,\"cl\":%u,\"fl\":%u,\"us\":%lu}",
    NODE_ID, (unsigned long)(millis() / 1000), tf[0], tf[1], tf[2], tf[3], lastRate,
    lastScore, state, lastFault, (unsigned long)lastInferUs);
  udp.beginPacket(dashIP, UDP_PORT);
  udp.write((const uint8_t*)buf, n);
  udp.endPacket();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n=== Edge Thermal AI - ESP32 ===");
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_BUZZ, OUTPUT);
  digitalWrite(PIN_LED, LOW);
  digitalWrite(PIN_BUZZ, BUZZ_ACTIVE_LOW ? HIGH : LOW);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);
  selfTest();
  WiFi.mode(WIFI_STA);
  wifiBegin();
  tSample = millis();
}

void loop() {
  uint32_t now = millis();
  if ((int32_t)(now - tSample) >= (int32_t)SAMPLE_MS) {
    tSample += SAMPLE_MS;
    if ((int32_t)(now - tSample) > 200) tSample = now;
    for (int i = 0; i < 4; i++) sbuf[i][sIdx] = analogRead(PIN_T[i]);
    if (++sIdx >= NS) { sIdx = 0; processFrame(); }
  }
  updateAlarm();
  wifiService();
  resolveDash();
  if (stateChanged || (now - tTelem) >= TELEMETRY_MS) {
    tTelem = now;
    stateChanged = false;
    sendTelemetry();
  }
}
