#include <WiFi.h>
#include <WiFiUdp.h>
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include <Adafruit_NeoPixel.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <math.h>
#include <string.h>
#include "model.h"

#define SIM_MODE 1
#define NODE_ID "node1"
#define UDP_PORT 4210
#define HOME_SSID "YOUR_WIFI_NAME"
#define HOME_PASS "YOUR_WIFI_PASSWORD"
#define DASH_HOST ""
#define SIM_DASH_HOST "host.wokwi.internal"
#define NTC_LOW_SIDE 1
#define BUZZ_ACTIVE_LOW 0
#define HARD_CRIT_C 65.0f
#define GAS_WARN_PPM 620
#define GAS_CRIT_PPM 820

float offs[4] = {0.0f, 0.0f, 0.0f, 0.0f};

#if SIM_MODE
#define WIFI_SSID_USED "Wokwi-GUEST"
#define WIFI_PASS_USED ""
#define DASH_HOST_USED SIM_DASH_HOST
#define AUTOZERO_ON 0
#else
#define WIFI_SSID_USED HOME_SSID
#define WIFI_PASS_USED HOME_PASS
#define DASH_HOST_USED DASH_HOST
#define AUTOZERO_ON 1
#endif

const uint8_t PIN_T[4] = {33, 32, 35, 34};
const uint8_t PIN_GAS = 36;
const uint8_t PIN_GAS_DO = 16;
const uint8_t PIN_BUZZ = 25;
const uint8_t PIN_LED = 26;
const uint8_t PIN_MATRIX = 13;
const uint8_t PIN_RELAY = 27;
const uint8_t PIN_SERVO = 14;
const uint8_t PIN_WIFI_KILL = 4;
const uint8_t PIN_SD_CS = 5;

const float BETA = 3950.0f;
const float R_FIXED = 10000.0f;
const float R_NOM = 10000.0f;
const float T_NOM_K = 298.15f;
const uint16_t FAULT_LO = 40;
const uint16_t FAULT_HI = 4055;

const uint8_t NS = 20;
const uint16_t SAMPLE_MS = 25;
const float FRAME_S = 0.5f;
const float EMA_A = 0.4f;
const uint8_t HN = 20;
const uint16_t TELEMETRY_MS = 1000;
const uint8_t UP_FRAMES = 2;
const uint8_t DOWN_FRAMES = 6;
const uint8_t AUTOZERO_FRAMES = 10;
const char* STATE_NAME[3] = {"NORMAL", "WARNING", "CRITICAL"};

Adafruit_NeoPixel matrix(64, PIN_MATRIX, NEO_GRB + NEO_KHZ800);
Adafruit_SSD1306 oled(128, 64, &Wire, -1);
bool oledReady = false;
bool sdReady = false;

uint16_t sbuf[4][NS];
uint16_t gbuf[NS];
uint8_t sIdx = 0;
uint32_t tSample = 0;
uint32_t tTelem = 0;
uint32_t tSdLog = 0;

uint32_t gasBaseSum = 0;
uint8_t gasBaseCnt = 0;
uint16_t gasBaseRaw = 0;
bool gasBaseReady = false;

float tf[4] = {25, 25, 25, 25};
float prevTf[4] = {25, 25, 25, 25};
float cellRate[4] = {0, 0, 0, 0};
bool tfInit = false;
float hist[HN];
uint8_t hCount = 0;
uint8_t hIdx = 0;

uint8_t state = 0;
uint8_t upCnt = 0;
uint8_t dnCnt = 0;
bool stateChanged = false;
float lastRate = 0.0f;
int lastScore = 0;
uint8_t lastFault = 0;
uint32_t lastInferUs = 0;

float coreTempC = 25.0f;
int gasPpm = 400;
int powerPct = 100;
bool relayTripped = false;
int servoDeg = 0;
int dominoIdx = 0;
int hotIdx = 0;
int ttrSec = -1;
float dynLimitC = 45.0f;
float dnaBase[4] = {0, 0, 0, 0};
float ambBase = 25.0f;
uint8_t dnaFrames = 0;
float dnaDev = 0.0f;
uint8_t swarmVotes = 0;
bool wifiKilled = false;

uint32_t chainHash = 0x811C9DC5UL;
char lastHashHex[9] = "811C9DC5";
uint32_t sdRecordCount = 0;

float azSum[4] = {0, 0, 0, 0};
uint8_t azFrames = 0;

#define OFFLINE_Q_SIZE 60
struct QueuedPkt {
  char data[340];
};
QueuedPkt offlineQ[OFFLINE_Q_SIZE];
uint8_t qHead = 0;
uint8_t qTail = 0;
uint8_t qCount = 0;

WiFiUDP udp;
IPAddress dashIP;
bool dashResolved = false;
static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

uint32_t updateChainHash(const char* s) {
  uint32_t h = chainHash;
  while (*s) {
    h ^= (uint8_t)(*s++);
    h *= 16777619UL;
  }
  chainHash = h;
  snprintf(lastHashHex, sizeof(lastHashHex), "%08lX", (unsigned long)chainHash);
  return chainHash;
}

void initServoPwm() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  ledcAttach(PIN_SERVO, 50, 16);
#else
  ledcSetup(4, 50, 16);
  ledcAttachPin(PIN_SERVO, 4);
#endif
}

void writeServoAngle(int deg) {
  deg = clampi(deg, 0, 180);
  uint32_t pulseUs = 500UL + ((uint32_t)deg * 1900UL) / 180UL;
  uint32_t duty = (pulseUs * 65535UL) / 20000UL;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  ledcWrite(PIN_SERVO, duty);
#else
  ledcWrite(4, duty);
#endif
}

void enqueueOffline(const char* payload) {
  strncpy(offlineQ[qTail].data, payload, sizeof(offlineQ[qTail].data) - 1);
  offlineQ[qTail].data[sizeof(offlineQ[qTail].data) - 1] = '\0';
  qTail = (qTail + 1) % OFFLINE_Q_SIZE;
  if (qCount < OFFLINE_Q_SIZE) {
    qCount++;
  } else {
    qHead = (qHead + 1) % OFFLINE_Q_SIZE;
  }
}

void makeFeatures(const float T[4], float rate, float f[MODEL_F]) {
  float tmax = T[0], tmin = T[0], sum = 0;
  for (int i = 0; i < 4; i++) {
    if (T[i] > tmax) tmax = T[i];
    if (T[i] < tmin) tmin = T[i];
    sum += T[i];
  }
  float tmean = sum / 4.0f;
  f[0] = clampf((tmax - 25.0f) / 50.0f, -1, 1);
  f[1] = clampf((tmean - 25.0f) / 50.0f, -1, 1);
  f[2] = clampf((tmax - tmin) / 25.0f, -1, 1);
  f[3] = clampf(rate / 10.0f, -1, 1);
  f[4] = clampf((tmax - tmean) / 10.0f, -1, 1);
}

void infer(const float f[MODEL_F], float p[MODEL_C]) {
  int8_t xq[MODEL_F], hq[MODEL_H];
  for (int i = 0; i < MODEL_F; i++) xq[i] = (int8_t)clampi((int)lrintf(f[i] * 127.0f), -127, 127);
  for (int j = 0; j < MODEL_H; j++) {
    int32_t acc = B1Q[j];
    for (int i = 0; i < MODEL_F; i++) acc += (int32_t)W1Q[j][i] * xq[i];
    hq[j] = (int8_t)clampi((int)lrintf((float)acc * M1), 0, 127);
  }
  float z[MODEL_C], zmax = -1e30f;
  for (int k = 0; k < MODEL_C; k++) {
    int32_t acc = B2Q[k];
    for (int j = 0; j < MODEL_H; j++) acc += (int32_t)W2Q[k][j] * hq[j];
    z[k] = (float)acc * M2;
    if (z[k] > zmax) zmax = z[k];
  }
  float s = 0;
  for (int k = 0; k < MODEL_C; k++) { p[k] = expf(z[k] - zmax); s += p[k]; }
  for (int k = 0; k < MODEL_C; k++) p[k] /= s;
}

int argmax(const float* p, int n) {
  int b = 0;
  for (int i = 1; i < n; i++) if (p[i] > p[b]) b = i;
  return b;
}

void selfTest() {
  bool ok = true;
  for (int k = 0; k < N_TESTS; k++) {
    float f[MODEL_F], p[MODEL_C];
    makeFeatures(TEST_T[k], TEST_RATE[k], f);
    infer(f, p);
    int c = argmax(p, MODEL_C);
    Serial.printf("[selftest %d] expect %s, got %s\n", k + 1, STATE_NAME[TEST_CLASS[k]], STATE_NAME[c]);
    if (c != TEST_CLASS[k]) ok = false;
  }
  Serial.println(ok ? "[selftest] PASS model loaded correctly" : "[selftest] FAIL");
}

float rawToC(uint16_t raw) {
  float r = (float)raw;
  float rn = NTC_LOW_SIDE ? R_FIXED * r / (4095.0f - r) : R_FIXED * (4095.0f - r) / r;
  return 1.0f / (logf(rn / R_NOM) / BETA + 1.0f / T_NOM_K) - 273.15f;
}

uint16_t medianFrame(const uint16_t* a) {
  uint16_t t[NS];
  memcpy(t, a, sizeof(t));
  for (int i = 1; i < NS; i++) {
    uint16_t v = t[i];
    int j = i - 1;
    while (j >= 0 && t[j] > v) { t[j + 1] = t[j]; j--; }
    t[j + 1] = v;
  }
  return (uint16_t)(((uint32_t)t[NS / 2 - 1] + t[NS / 2]) / 2);
}

void initBlackBoxSD() {
  SPI.begin(18, 19, 23, PIN_SD_CS);
  sdReady = SD.begin(PIN_SD_CS, SPI, 4000000);
  if (!sdReady) {
    Serial.println("[sd] microSD init failed");
    return;
  }
  if (!SD.exists("/blackbox.csv")) {
    File f = SD.open("/blackbox.csv", FILE_WRITE);
    if (f) {
      f.println("uptime_s,state,score,T1,T2,T3,T4,core_c,gas_ppm,power_pct,relay,servo_deg,domino,fault_mask,hash_stamp");
      f.close();
    }
  }
  Serial.println("[sd] Black-Box ready (/blackbox.csv) - type DUMP in Serial to read");
}

void writeBlackBoxRecord() {
  char row[192];
  snprintf(row, sizeof(row), "%lu,%s,%d,%.1f,%.1f,%.1f,%.1f,%.1f,%d,%d,%d,%d,T%d,%u",
           (unsigned long)(millis() / 1000), STATE_NAME[state], lastScore,
           tf[0], tf[1], tf[2], tf[3], coreTempC, gasPpm, powerPct,
           relayTripped ? 1 : 0, servoDeg, dominoIdx + 1, lastFault);
  updateChainHash(row);
  if (!sdReady) return;
  File f = SD.open("/blackbox.csv", FILE_APPEND);
  if (f) {
    f.print(row);
    f.print(",");
    f.println(lastHashHex);
    f.close();
    sdRecordCount++;
  }
}

void handleSerialCommands() {
  if (!Serial.available()) return;
  String cmd = Serial.readStringUntil('\n');
  cmd.trim();
  cmd.toUpperCase();
  if (cmd == "DUMP") {
    if (!sdReady) { Serial.println("[sd] unavailable"); return; }
    File f = SD.open("/blackbox.csv", FILE_READ);
    if (!f) { Serial.println("[sd] file missing"); return; }
    Serial.println("=== BLACK-BOX SD DUMP START ===");
    while (f.available()) Serial.write(f.read());
    f.close();
    Serial.printf("=== BLACK-BOX SD DUMP END (%lu records) ===\n", (unsigned long)sdRecordCount);
  } else if (cmd == "CLEAR" && sdReady) {
    SD.remove("/blackbox.csv");
    sdRecordCount = 0;
    initBlackBoxSD();
    Serial.println("[sd] Black-Box cleared");
  }
}
uint32_t heatColor(float tempC) {
  float n = clampf((tempC - 22.0f) / 48.0f, 0.0f, 1.0f);
  uint8_t r = 0, g = 0, b = 0;
  if (n < 0.33f) {
    float t = n / 0.33f;
    g = (uint8_t)(t * 180);
    b = (uint8_t)((1.0f - t) * 200);
  } else if (n < 0.66f) {
    float t = (n - 0.33f) / 0.33f;
    r = (uint8_t)(t * 240);
    g = (uint8_t)(180 - t * 40);
  } else {
    float t = (n - 0.66f) / 0.34f;
    r = 255;
    g = (uint8_t)((1.0f - t) * 140);
  }
  return matrix.Color(r, g, b);
}

void interpolate8x8(float grid[64]) {
  for (int r = 0; r < 8; r++) {
    float fy = r / 7.0f;
    for (int c = 0; c < 8; c++) {
      float fx = c / 7.0f;
      float top = tf[0] * (1.0f - fx) + tf[1] * fx;
      float bot = tf[2] * (1.0f - fx) + tf[3] * fx;
      grid[r * 8 + c] = top * (1.0f - fy) + bot * fy;
    }
  }
}

void updateMatrix() {
  float grid[64];
  interpolate8x8(grid);
  bool blinkDomino = ((millis() / 350) % 2) == 0;
  int dRow = (dominoIdx >= 2) ? 6 : 1;
  int dCol = (dominoIdx % 2 == 1) ? 6 : 1;
  for (int r = 0; r < 8; r++) {
    for (int c = 0; c < 8; c++) {
      uint32_t col = heatColor(grid[r * 8 + c]);
      if (state >= 1 && blinkDomino && r == dRow && c == dCol) {
        col = matrix.Color(255, 0, 255);
      }
      matrix.setPixelColor(r * 8 + c, col);
    }
  }
  matrix.show();
}

void updateOled() {
  if (!oledReady) return;
  oled.clearDisplay();
  oled.setTextSize(1);
  oled.setTextColor(SSD1306_WHITE);
  oled.setCursor(0, 0);
  oled.printf("%s SC:%d %s", STATE_NAME[state], lastScore, wifiKilled ? "OFF" : "NET");
  oled.setCursor(0, 12);
  oled.printf("Core:%.1fC Gas:%d", coreTempC, gasPpm);
  oled.setCursor(0, 24);
  oled.printf("Pwr:%d%% Vlv:%d", powerPct, servoDeg);
  oled.setCursor(0, 36);
  oled.printf("Next:T%d Rel:%s", dominoIdx + 1, relayTripped ? "CUT" : "ON");
  oled.setCursor(0, 48);
  if (lastFault) {
    oled.printf("GHOST:M%u SD:%lu", lastFault, (unsigned long)sdRecordCount);
  } else if (ttrSec >= 0) {
    oled.printf("TTR:%ds SD:%lu", ttrSec, (unsigned long)sdRecordCount);
  } else {
    oled.printf("SD:%lu Q:%u #%s", (unsigned long)sdRecordCount, qCount, lastHashHex + 4);
  }
  oled.display();
}

void processFrame() {
  float tc[4];
  uint8_t fault = 0, nValid = 0;
  for (int i = 0; i < 4; i++) {
    uint16_t raw = medianFrame(sbuf[i]);
    if (raw < FAULT_LO || raw > FAULT_HI) {
      fault |= (1 << i);
      tc[i] = 0;
    } else {
      tc[i] = rawToC(raw) + offs[i];
      nValid++;
    }
  }
  lastFault = fault;

  uint16_t rawGas = medianFrame(gbuf);
  bool gasDigAlarm = (digitalRead(PIN_GAS_DO) == HIGH);
  if (!gasBaseReady) {
    gasBaseSum += rawGas;
    if (++gasBaseCnt >= 4) {
      gasBaseRaw = (uint16_t)(gasBaseSum / gasBaseCnt);
      gasBaseReady = true;
    }
    gasPpm = 400;
  } else {
    int delta = (int)rawGas - (int)gasBaseRaw;
    gasPpm = clampi(400 + (delta * 600) / 1200, 300, 1000);
  }
  if (gasDigAlarm && gasPpm < 860) gasPpm = 860;

  int cls = 0;
  float p[MODEL_C] = {1, 0, 0};
  float tmax = tf[0];

  if (nValid == 0) {
    cls = 1;
    lastScore = 50;
    lastRate = 0;
    lastInferUs = 0;
  } else {
    for (int i = 0; i < 4; i++) {
      if (fault & (1 << i)) {
        int adj1 = i ^ 1;
        int adj2 = i ^ 2;
        int diag = i ^ 3;
        float wSum = 0.0f, tSum = 0.0f;
        if (!(fault & (1 << adj1))) { tSum += tc[adj1] * 0.42f; wSum += 0.42f; }
        if (!(fault & (1 << adj2))) { tSum += tc[adj2] * 0.42f; wSum += 0.42f; }
        if (!(fault & (1 << diag))) { tSum += tc[diag] * 0.16f; wSum += 0.16f; }
        tc[i] = (wSum > 0.0f) ? (tSum / wSum) : 25.0f;
      }
    }

#if AUTOZERO_ON
    if (azFrames < AUTOZERO_FRAMES && fault == 0) {
      for (int i = 0; i < 4; i++) azSum[i] += tc[i];
      if (++azFrames == AUTOZERO_FRAMES) {
        float g = 0;
        for (int i = 0; i < 4; i++) g += azSum[i] / azFrames;
        g /= 4.0f;
        for (int i = 0; i < 4; i++) {
          float d = g - azSum[i] / azFrames;
          if (fabsf(d) < 3.0f) offs[i] += d;
        }
      }
    }
#endif

    if (!tfInit) {
      for (int i = 0; i < 4; i++) { tf[i] = tc[i]; prevTf[i] = tc[i]; }
      tfInit = true;
    } else {
      for (int i = 0; i < 4; i++) {
        prevTf[i] = tf[i];
        tf[i] += EMA_A * (tc[i] - tf[i]);
        cellRate[i] = (tf[i] - prevTf[i]) / FRAME_S * 60.0f;
      }
    }

    tmax = tf[0];
    hotIdx = 0;
    float sumT = 0.0f;
    for (int i = 0; i < 4; i++) {
      sumT += tf[i];
      if (tf[i] > tmax) { tmax = tf[i]; hotIdx = i; }
    }
    float tmean = sumT / 4.0f;

    if (dnaFrames < 10 && fault == 0 && tmax < 40.0f) {
      ambBase = (ambBase * dnaFrames + tmean) / (dnaFrames + 1);
      for (int i = 0; i < 4; i++) {
        dnaBase[i] = (dnaBase[i] * dnaFrames + (tf[i] - tmean)) / (dnaFrames + 1);
      }
      dnaFrames++;
    }
    dynLimitC = clampf(ambBase + 20.0f, 40.0f, 52.0f);
    dnaDev = 0.0f;
    for (int i = 0; i < 4; i++) dnaDev += fabsf((tf[i] - tmean) - dnaBase[i]);
    dnaDev /= 4.0f;

    hist[hIdx] = tmax;
    hIdx = (hIdx + 1) % HN;
    if (hCount < HN) hCount++;
    uint8_t oldest = (hCount < HN) ? 0 : hIdx;
    uint8_t span = hCount - 1;
    lastRate = (span < 4) ? 0.0f : clampf((tmax - hist[oldest]) / (span * FRAME_S) * 60.0f, -30.0f, 30.0f);

    float ratePerSec = lastRate / 60.0f;
    coreTempC = tmax + (ratePerSec > 0.0f ? ratePerSec * 18.0f : 0.0f) + 0.35f * (tmax - tmean);

    int adjA = hotIdx ^ 1;
    int adjB = hotIdx ^ 2;
    float riskA = tf[adjA] + 0.4f * cellRate[adjA];
    float riskB = tf[adjB] + 0.4f * cellRate[adjB];
    dominoIdx = (riskA >= riskB) ? adjA : adjB;

    if (coreTempC >= HARD_CRIT_C) {
      ttrSec = 0;
    } else if (lastRate > 0.5f) {
      ttrSec = clampi((int)(((HARD_CRIT_C - coreTempC) / lastRate) * 60.0f), 1, 999);
    } else {
      ttrSec = -1;
    }

    float f[MODEL_F];
    makeFeatures(tf, lastRate, f);
    uint32_t t0 = micros();
    infer(f, p);
    lastInferUs = micros() - t0;
    cls = argmax(p, MODEL_C);
    lastScore = clampi((int)lrintf(100.0f * (0.5f * p[1] + p[2])), 0, 100);

    if (dnaDev > 5.0f && cls == 0 && tmax > dynLimitC - 4.0f) {
      cls = 1;
      lastScore = clampi(lastScore + 20, 45, 100);
    }
    if (gasPpm >= GAS_WARN_PPM) {
      lastScore = clampi(lastScore + 25, 0, 100);
      if (cls < 1) cls = 1;
    }
    if (gasDigAlarm || (gasPpm >= GAS_CRIT_PPM && coreTempC >= 38.0f)) {
      cls = 2;
      lastScore = clampi(lastScore + 40, 88, 100);
    }

    swarmVotes = 0;
    for (int i = 0; i < 4; i++) if (tf[i] >= dynLimitC - 5.0f) swarmVotes++;
    if (gasPpm >= GAS_WARN_PPM) swarmVotes++;

    bool hard = (nValid > 0 && (tmax >= HARD_CRIT_C || coreTempC >= HARD_CRIT_C + 5.0f));
    if (hard) { cls = 2; lastScore = 100; }

    uint8_t prev = state;
    if (hard) { state = 2; upCnt = dnCnt = 0; }
    else if (cls > state) { dnCnt = 0; if (++upCnt >= UP_FRAMES) { state = cls; upCnt = 0; } }
    else if (cls < state) { upCnt = 0; if (++dnCnt >= DOWN_FRAMES) { state = cls; dnCnt = 0; } }
    else { upCnt = dnCnt = 0; }
    if (state != prev) stateChanged = true;
  }

  if (state == 2) {
    powerPct = 0;
    relayTripped = true;
    servoDeg = 180;
  } else if (state == 1) {
    powerPct = clampi(100 - (lastScore - 25), 40, 75);
    relayTripped = false;
    servoDeg = clampi(45 + (lastScore - 35) * 2, 45, 135);
  } else {
    powerPct = 100;
    relayTripped = false;
    servoDeg = (coreTempC > dynLimitC - 6.0f) ? 30 : 0;
  }

  digitalWrite(PIN_RELAY, relayTripped ? LOW : HIGH);
  writeServoAngle(servoDeg);
  updateMatrix();
  updateOled();

  uint32_t sdInterval = (state >= 1) ? 1000 : 5000;
  if (stateChanged || (millis() - tSdLog >= sdInterval)) {
    tSdLog = millis();
    writeBlackBoxRecord();
  }

  Serial.printf("[%.1f %.1f %.1f %.1f] core=%.1f gas=%d pwr=%d%% vlv=%d next=T%d sc=%d %s AI=%luus SD=%lu #%s%s\n",
                tf[0], tf[1], tf[2], tf[3], coreTempC, gasPpm, powerPct, servoDeg, dominoIdx + 1,
                lastScore, STATE_NAME[state], (unsigned long)lastInferUs, (unsigned long)sdRecordCount,
                lastHashHex, lastFault ? " GHOST_ACTIVE" : "");
}
bool buzzNow = false;
void setBuzzer(bool on) {
  if (on == buzzNow) return;
  buzzNow = on;
#if SIM_MODE
  if (on) tone(PIN_BUZZ, 2000); else noTone(PIN_BUZZ);
#else
  digitalWrite(PIN_BUZZ, (on ^ (bool)BUZZ_ACTIVE_LOW) ? HIGH : LOW);
#endif
}

void updateAlarm() {
  uint32_t now = millis();
  bool led = false, bz = false;
  if (state == 2) { led = true; bz = ((now / 200) % 2) == 0; }
  else if (state == 1) { led = ((now / 500) % 2) == 0; bz = (now % 2000) < 100; }
  else if (lastFault) { led = ((now / 125) % 2) == 0; }
  digitalWrite(PIN_LED, led ? HIGH : LOW);
  setBuzzer(bz);
}

void wifiBegin() {
#if SIM_MODE
  WiFi.begin(WIFI_SSID_USED, WIFI_PASS_USED, 6);
#else
  WiFi.begin(WIFI_SSID_USED, WIFI_PASS_USED);
#endif
}

void wifiService() {
  static uint32_t lastTry = 0;
  static bool announced = false;
  bool killNow = (digitalRead(PIN_WIFI_KILL) == HIGH);
  if (killNow != wifiKilled) {
    wifiKilled = killNow;
    if (wifiKilled) {
      WiFi.disconnect(true);
      announced = false;
      dashResolved = false;
      Serial.println("[wifi] KILL SWITCH ACTIVE - autonomous offline storage mode");
    } else {
      Serial.println("[wifi] KILL SWITCH RELEASED - reconnecting & syncing queue");
      wifiBegin();
    }
  }
  if (wifiKilled) return;
  if (WiFi.status() == WL_CONNECTED) {
    if (!announced) {
      announced = true;
      Serial.print("[wifi] connected, IP ");
      Serial.println(WiFi.localIP());
    }
    return;
  }
  announced = false;
  dashResolved = false;
  if (millis() - lastTry > 10000) {
    lastTry = millis();
    WiFi.disconnect();
    wifiBegin();
  }
}

void resolveDash() {
  static uint32_t last = 0;
  if (wifiKilled || dashResolved || WiFi.status() != WL_CONNECTED) return;
  if (last && millis() - last < 30000) return;
  last = millis();
  const char* host = DASH_HOST_USED;
  if (host[0] == 0) { dashIP = WiFi.broadcastIP(); dashResolved = true; return; }
  if (dashIP.fromString(host)) { dashResolved = true; return; }
  dashResolved = WiFi.hostByName(host, dashIP);
}

void flushOfflineQueue() {
  if (wifiKilled || WiFi.status() != WL_CONNECTED || !dashResolved || qCount == 0) return;
  int burst = 0;
  while (qCount > 0 && burst < 4) {
    udp.beginPacket(dashIP, UDP_PORT);
    udp.write((const uint8_t*)offlineQ[qHead].data, strlen(offlineQ[qHead].data));
    udp.endPacket();
    qHead = (qHead + 1) % OFFLINE_Q_SIZE;
    qCount--;
    burst++;
  }
  if (qCount == 0) Serial.println("[sync] Offline RAM queue fully synced to dashboard");
}

void sendTelemetry() {
  char base[320];
  snprintf(base, sizeof(base),
           "{\"id\":\"%s\",\"up\":%lu,\"t\":[%.1f,%.1f,%.1f,%.1f],\"r\":%.1f,\"sc\":%d,\"cl\":%u,\"fl\":%u,\"us\":%lu,"
           "\"core\":%.1f,\"gas\":%d,\"pwr\":%d,\"rel\":%d,\"srv\":%d,\"dom\":%d,\"dna\":%.1f,\"ttr\":%d,\"dl\":%.1f,"
           "\"sw\":%u,\"hs\":\"%s\",\"sd\":%lu,\"q\":%u",
           NODE_ID, (unsigned long)(millis() / 1000), tf[0], tf[1], tf[2], tf[3], lastRate,
           lastScore, state, lastFault, (unsigned long)lastInferUs,
           coreTempC, gasPpm, powerPct, relayTripped ? 1 : 0, servoDeg, dominoIdx, dnaDev, ttrSec,
           dynLimitC, swarmVotes, lastHashHex, (unsigned long)sdRecordCount, qCount);

  if (wifiKilled || WiFi.status() != WL_CONNECTED || !dashResolved) {
    char qBuf[340];
    snprintf(qBuf, sizeof(qBuf), "%s,\"sync\":1}", base);
    enqueueOffline(qBuf);
    return;
  }

  flushOfflineQueue();

  char pkt[680];
  if (state >= 1) {
    float g[64];
    interpolate8x8(g);
    int pos = snprintf(pkt, sizeof(pkt), "%s,\"hm\":[", base);
    for (int i = 0; i < 64 && pos < (int)sizeof(pkt) - 8; i++) {
      pos += snprintf(pkt + pos, sizeof(pkt) - pos, "%d%s", (int)lrintf(g[i]), (i < 63) ? "," : "");
    }
    snprintf(pkt + pos, sizeof(pkt) - pos, "]}");
  } else {
    snprintf(pkt, sizeof(pkt), "%s}", base);
  }

  udp.beginPacket(dashIP, UDP_PORT);
  udp.write((const uint8_t*)pkt, strlen(pkt));
  udp.endPacket();
}

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("\n=== Edge Thermal AI v2 ===");
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_BUZZ, OUTPUT);
  pinMode(PIN_RELAY, OUTPUT);
  pinMode(PIN_WIFI_KILL, INPUT_PULLUP);
  pinMode(PIN_GAS_DO, INPUT);
  digitalWrite(PIN_LED, LOW);
  digitalWrite(PIN_BUZZ, BUZZ_ACTIVE_LOW ? HIGH : LOW);
  digitalWrite(PIN_RELAY, HIGH);
  analogReadResolution(12);
  analogSetAttenuation(ADC_11db);

  initServoPwm();
  writeServoAngle(0);

  matrix.begin();
  matrix.setBrightness(90);
  matrix.show();

  Wire.begin(21, 22);
  oledReady = oled.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  if (oledReady) {
    oled.clearDisplay();
    oled.setTextSize(1);
    oled.setTextColor(SSD1306_WHITE);
    oled.setCursor(0, 20);
    oled.println("Edge Thermal AI v2");
    oled.display();
  }

  initBlackBoxSD();
  selfTest();
  WiFi.mode(WIFI_STA);
  wifiKilled = (digitalRead(PIN_WIFI_KILL) == HIGH);
  if (!wifiKilled) wifiBegin();
  else Serial.println("[wifi] KILL SWITCH ACTIVE at boot");
  tSample = millis();
}

void loop() {
  uint32_t now = millis();
  handleSerialCommands();
  if ((int32_t)(now - tSample) >= (int32_t)SAMPLE_MS) {
    tSample += SAMPLE_MS;
    if ((int32_t)(now - tSample) > 200) tSample = now;
    for (int i = 0; i < 4; i++) sbuf[i][sIdx] = analogRead(PIN_T[i]);
    gbuf[sIdx] = analogRead(PIN_GAS);
    if (++sIdx >= NS) { sIdx = 0; processFrame(); }
  }
  updateAlarm();
  wifiService();
  resolveDash();
  if (stateChanged || (now - tTelem) >= TELEMETRY_MS) {
    tTelem = now;
    stateChanged = false;
    sendTelemetry();
  }
}