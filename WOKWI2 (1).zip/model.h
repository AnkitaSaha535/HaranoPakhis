#pragma once
#include <stdint.h>

#define MODEL_F 5
#define MODEL_H 12
#define MODEL_C 3

static const int8_t W1Q[12][5] = {
  {-3, -6, -3, 0, -5},
  {-9, -9, 9, -7, -15},
  {-11, -3, -3, 3, -13},
  {23, -4, 45, 80, -14},
  {-39, 24, 14, -39, -3},
  {-15, 45, 29, -55, -4},
  {53, 3, 10, 57, 8},
  {8, -57, 33, -7, -37},
  {-38, 37, 1, -50, 17},
  {127, 48, 35, -122, -8},
  {0, -2, -20, -4, -4},
  {-72, -89, -5, 87, -15}
};

static const int32_t B1Q[12] = {-139, -254, -196, 988, 5809, 4467, -1073, 2763, 6333, -3512, -235, -1093};

static const int8_t W2Q[3][12] = {
  {-2, -3, 1, -38, 48, 42, -40, -28, 42, -109, -6, 115},
  {3, -1, 3, 6, 13, 5, 5, -65, -13, -7, 5, -11},
  {1, 0, 5, 5, -62, -54, 34, 112, -53, 70, -9, -127}
};

static const int32_t B2Q[3] = {111, 82, -169};

static const float M1 = 4.721189849e-03f;
static const float M2 = 8.835001849e-03f;

#define N_TESTS 4
static const float TEST_T[N_TESTS][4] = {
  {28.0f, 29.0f, 28.0f, 29.0f},
  {52.0f, 40.0f, 38.0f, 36.0f},
  {72.0f, 55.0f, 50.0f, 48.0f},
  {36.0f, 35.0f, 36.0f, 35.0f}
};
static const float TEST_RATE[N_TESTS] = {0.2f, 2.0f, 12.0f, 7.0f};
static const uint8_t TEST_CLASS[N_TESTS] = {0, 1, 2, 1};